<?php

/* home/home.html.twig */
class __TwigTemplate_c459f8b300597b25a7e7ae706d5ca93a43a13fad8746cdf05b91d59738926488 extends Twig_Template
{
    private $source;

    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        // line 1
        $this->parent = $this->loadTemplate("base.html.twig", "home/home.html.twig", 1);
        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'body' => array($this, 'block_body'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "home/home.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

    }

    // line 3
    public function block_title($context, array $blocks = array())
    {
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        echo "Craftscity";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

    }

    // line 5
    public function block_body($context, array $blocks = array())
    {
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 6
        echo "    <div>
        <img id=\"background\" src=\"";
        // line 7
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("/assets/www16.jpg"), "html", null, true);
        echo "\" alt=\"background\">
    </div>
    <a class=\"table\" href=\"";
        // line 9
        echo $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("products_list");
        echo "\"></a>
    <a class=\"game\" href=\"";
        // line 10
        echo $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("products_list");
        echo "\"></a>
    <a class=\"frame\" href=\"";
        // line 11
        echo $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("products_list");
        echo "\"></a>
    <a class=\"frame2\" href=\"";
        // line 12
        echo $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("products_list");
        echo "\"></a>
    <a class=\"shelf\" href=\"";
        // line 13
        echo $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("products_list");
        echo "\"></a>
    <a class=\"shelves\" href=\"";
        // line 14
        echo $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("products_list");
        echo "\"></a>
    <a class=\"clock\" href=\"http://www.dim-time.ru\"></a>
    <a class=\"statue\" href=\"";
        // line 16
        echo $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("products_list");
        echo "\"></a>
    <a class=\"toy\" href=\"";
        // line 17
        echo $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("products_list");
        echo "\"></a>
    <a class=\"mirror\" href=\"https://www.fusiondom.ru\"></a>
";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

    }

    public function getTemplateName()
    {
        return "home/home.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  94 => 17,  90 => 16,  85 => 14,  81 => 13,  77 => 12,  73 => 11,  69 => 10,  65 => 9,  60 => 7,  57 => 6,  51 => 5,  39 => 3,  15 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends 'base.html.twig' %}

{% block title %}Craftscity{% endblock %}

{% block body %}
    <div>
        <img id=\"background\" src=\"{{ asset('/assets/www16.jpg') }}\" alt=\"background\">
    </div>
    <a class=\"table\" href=\"{{ path('products_list') }}\"></a>
    <a class=\"game\" href=\"{{ path('products_list') }}\"></a>
    <a class=\"frame\" href=\"{{ path('products_list') }}\"></a>
    <a class=\"frame2\" href=\"{{ path('products_list') }}\"></a>
    <a class=\"shelf\" href=\"{{ path('products_list') }}\"></a>
    <a class=\"shelves\" href=\"{{ path('products_list') }}\"></a>
    <a class=\"clock\" href=\"http://www.dim-time.ru\"></a>
    <a class=\"statue\" href=\"{{ path('products_list') }}\"></a>
    <a class=\"toy\" href=\"{{ path('products_list') }}\"></a>
    <a class=\"mirror\" href=\"https://www.fusiondom.ru\"></a>
{% endblock %}
", "home/home.html.twig", "C:\\xampp1\\htdocs\\craftscity\\templates\\home\\home.html.twig");
    }
}
